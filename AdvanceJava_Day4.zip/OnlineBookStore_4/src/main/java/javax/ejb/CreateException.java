package javax.ejb;

public class CreateException {

}
