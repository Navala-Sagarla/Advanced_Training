package com.navala.order;

public interface EJBObject {

}
