package com.navala.order;

public class CreateException extends Exception {

}
