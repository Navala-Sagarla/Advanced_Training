package com.navala.order;

public interface SessionBean {

}
