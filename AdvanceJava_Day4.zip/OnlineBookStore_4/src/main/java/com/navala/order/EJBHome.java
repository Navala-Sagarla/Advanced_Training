package com.navala.order;

public interface EJBHome {

}
