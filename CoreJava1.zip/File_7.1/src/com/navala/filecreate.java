package com.navala;

import java.io.File;
import java.io.IOException;

public class filecreate {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file=new File("C:\\Users\\KRAN3\\OneDrive\\Desktop\\hi.txt");
		file.createNewFile();
		File file2=new File("C:\\Users\\KRAN3\\OneDrive\\Desktop\\hi1.txt");
		file2.createNewFile();

	}

}
