package com.navala;

public class instrument {
	public abstract class Instrument
	{
	public abstract void Play();
	}
}